#!/bin/bash
# 场景2: 表单填写验证脚本
# 从 form-test.yaml 生成的脚本

set -e  # 遇到错误立即退出

# 启用人工模拟模式
export AGENT_BROWSER_HUMAN=bezier
SESSION="form-verify-$(date +%s)"

# 测试页面路径
TEST_PAGE="file:///Users/xuyingzhou/Project/temporary/agent-browser/test-pages/form-test.html"

echo "=== 开始执行表单填写脚本 ==="
echo "Session: $SESSION"
echo "AGENT_BROWSER_HUMAN: $AGENT_BROWSER_HUMAN"

# 打开测试页面
echo "1. 打开表单测试页面..."
agent-browser --session $SESSION --allow-file-access --headed open "$TEST_PAGE"
agent-browser --session $SESSION wait --load networkidle

# 填写表单
echo "2. 填写表单..."
agent-browser --session $SESSION fill "#name" "测试用户"
agent-browser --session $SESSION fill "#email" "test@example.com"
agent-browser --session $SESSION fill "#password" "password123"
agent-browser --session $SESSION select "#country" "cn"
agent-browser --session $SESSION check "#agree"

# 提交表单
echo "3. 提交表单..."
agent-browser --session $SESSION click "#submitBtn"

# 等待结果显示
agent-browser --session $SESSION wait 500

# 验证结果
echo "4. 验证结果..."
URL=$(agent-browser --session $SESSION get url)
echo "当前URL: $URL"

# 检查URL是否正确
if [[ "$URL" == *"form-test.html"* ]]; then
    echo "✓ URL验证成功"
else
    echo "✗ URL验证失败"
    agent-browser --session $SESSION close
    exit 1
fi

# 检查表单数据是否显示
RESULT=$(agent-browser --session $SESSION get text "#result")
if [[ "$RESULT" == *"测试用户"* ]]; then
    echo "✓ 表单数据验证成功"
else
    echo "✗ 表单数据验证失败"
    agent-browser --session $SESSION close
    exit 1
fi

# 清理
echo "5. 关闭浏览器..."
agent-browser --session $SESSION close

echo "=== 脚本执行成功 ==="
exit 0