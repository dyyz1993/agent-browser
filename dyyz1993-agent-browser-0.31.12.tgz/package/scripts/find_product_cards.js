(() => {
  const result = {
    bodyClasses: document.body.className,
    children: []
  };
  
  const mainContent = document.querySelector('main, #J_goodsList, [id*="goods"], [id*="product"]');
  
  if (mainContent) {
    result.mainContainer = {
      id: mainContent.id,
      className: mainContent.className,
      childrenCount: mainContent.children.length
    };
    
    Array.from(mainContent.children).slice(0, 5).forEach((child, index) => {
      result.children.push({
        index,
        tagName: child.tagName,
        className: child.className,
        id: child.id,
        innerHTML: child.innerHTML.substring(0, 200)
      });
    });
  } else {
    Array.from(document.body.querySelectorAll('div')).slice(0, 20).forEach((div, index) => {
      result.children.push({
        index,
        tagName: div.tagName,
        className: div.className,
        id: div.id,
        innerHTML: div.innerHTML.substring(0, 200)
      });
    });
  }
  
  return result;
})()
