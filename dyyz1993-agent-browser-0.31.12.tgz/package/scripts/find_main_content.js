(() => {
  const result = {
    bodyChildren: []
  };
  
  const bodyChildren = document.body.children;
  
  for (let i = 0; i < Math.min(bodyChildren.length, 30); i++) {
    const child = bodyChildren[i];
    result.bodyChildren.push({
      index: i,
      tagName: child.tagName,
      id: child.id,
      className: child.className,
      childrenCount: child.children.length
    });
  }
  
  return result;
})()
