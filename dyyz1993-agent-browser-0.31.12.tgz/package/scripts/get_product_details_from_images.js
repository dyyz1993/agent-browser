(async () => {
  const result = {
    products: []
  };
  
  const wrappers = document.querySelectorAll('._wrapper_8g5fc_1');
  
  wrappers.forEach((wrapper, index) => {
    if (index >= 10) return;
    
    const product = {
      index,
      className: wrapper.className
    };
    
    const img = wrapper.querySelector('img');
    if (img) {
      product.img = img.getAttribute('data-src')?.substring(0, 100) || img.src?.substring(0, 100);
    }
    
    const parentLink = wrapper.closest('a');
    if (parentLink) {
      product.link = parentLink.href;
    }
    
    const allText = wrapper.textContent?.trim() || '';
    product.text = allText.substring(0, 150);
    
    const priceElements = wrapper.querySelectorAll('*');
    for (const el of priceElements) {
      const text = el.textContent?.trim() || '';
      if (text.match(/[¥￥]\s*\d+/)) {
        product.price = text;
        break;
      }
    }
    
    const greatGrandParent = wrapper.parentElement?.parentElement?.parentElement;
    if (greatGrandParent) {
      product.greatGrandParentClass = greatGrandParent.className?.substring(0, 100);
      const greatGrandParentText = greatGrandParent.textContent?.trim() || '';
      product.greatGrandParentText = greatGrandParentText.substring(0, 200);
      
      const greatGrandParentLink = greatGrandParent.querySelector('a[href*="jd"]');
      if (greatGrandParentLink) {
        product.link = greatGrandParentLink.href;
      }
    }
    
    result.products.push(product);
  });
  
  return result;
})()
