(() => {
  const result = {
    visibleElements: [],
    linksWithProductInClass: []
  };
  
  const allElements = document.querySelectorAll('*');
  let count = 0;
  
  for (const el of allElements) {
    if (count >= 50) break;
    
    const className = el.className ? String(el.className) : '';
    const text = el.textContent?.trim() || '';
    
    if ((className.includes('product') || className.includes('item') || className.includes('card')) && text.length > 10) {
      result.visibleElements.push({
        tagName: el.tagName,
        className: className.substring(0, 100),
        text: text.substring(0, 100)
      });
      count++;
    }
  }
  
  const productLinks = document.querySelectorAll('a[href*="item.jd"], a[href*="product.jd"]');
  productLinks.forEach((link, index) => {
    if (index >= 10) return;
    result.linksWithProductInClass.push({
      href: link.href.substring(0, 100),
      text: link.textContent?.substring(0, 50)
    });
  });
  
  return result;
})()
