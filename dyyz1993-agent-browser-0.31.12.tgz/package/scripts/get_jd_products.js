(() => {
  const items = document.querySelectorAll('.gl-item');
  const products = [];
  
  items.forEach((item, index) => {
    const titleEl = item.querySelector('.p-name a');
    const priceEl = item.querySelector('.p-price');
    const shopEl = item.querySelector('.p-shop a');
    const salesEl = item.querySelector('.p-commit');
    const linkEl = item.querySelector('.p-name a');
    
    products.push({
      index: index,
      title: titleEl?.textContent?.trim() || '',
      price: priceEl?.textContent?.trim() || '',
      shop: shopEl?.textContent?.trim() || '',
      sales: salesEl?.textContent?.trim() || '',
      link: linkEl?.href || ''
    });
  });
  
  return products.slice(0, 10);
})()
