#!/bin/bash
# 场景8: 登录功能验证脚本（含验证码识别）

set -e
export AGENT_BROWSER_HUMAN=bezier
SESSION="login-verify-$(date +%s)"
TEST_PAGE="file:///Users/xuyingzhou/Project/temporary/agent-browser/test-pages/login-test.html"

echo "=== 开始执行登录验证脚本 ==="
echo "Session: $SESSION"

# 打开测试页面
echo "1. 打开登录测试页面..."
agent-browser --session $SESSION --allow-file-access --headed open "$TEST_PAGE"
agent-browser --session $SESSION wait --load networkidle

# 检查未登录标识
echo "2. 检查未登录标识..."
UNLOGGED=$(agent-browser --session $SESSION get text "#loggedOutIndicator")
if [[ "$UNLOGGED" == *"尚未登录"* ]]; then
    echo "✓ 检测到未登录标识"
else
    echo "✗ 未检测到未登录标识"
fi

# 获取验证码并立即填写（使用链式命令减少延迟）
echo "3. 获取验证码并填写..."
agent-browser --session $SESSION eval --stdin <<'EOF'
const captcha = document.getElementById("captchaCode").textContent;
document.getElementById("username").value = "testuser";
document.getElementById("password").value = "password123";
document.getElementById("captcha").value = captcha;
"验证码: " + captcha;
EOF

echo "4. 提交登录..."
agent-browser --session $SESSION click "#loginBtn"
agent-browser --session $SESSION wait 500

# 验证登录结果
echo "6. 验证登录结果..."
STATUS=$(agent-browser --session $SESSION get text "#loginStatus")
if [[ "$STATUS" == *"登录成功"* ]]; then
    echo "✓ 登录成功"
else
    echo "✗ 登录失败: $STATUS"
    agent-browser --session $SESSION close
    exit 1
fi

# 检查用户信息显示
echo "7. 检查用户信息..."
USERINFO=$(agent-browser --session $SESSION get text "#userInfo")
if [[ "$USERINFO" == *"testuser"* ]]; then
    echo "✓ 用户信息显示正确"
else
    echo "✗ 用户信息显示错误"
fi

# 清理
echo "8. 关闭浏览器..."
agent-browser --session $SESSION close

echo "=== 脚本执行成功 ==="
exit 0