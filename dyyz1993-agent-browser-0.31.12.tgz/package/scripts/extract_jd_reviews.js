(() => {
  const result = {
    reviews: {
      total: '',
      good: '',
      neutral: '',
      bad: ''
    },
    allReviewText: []
  };
  
  const allText = document.body.textContent;
  
  const totalMatch = allText.match(/买家评价[（(](\d+[+万])[）)]/);
  if (totalMatch) {
    result.reviews.total = totalMatch[1];
  }
  
  const reviewButtons = document.querySelectorAll('[class*="filter"], [class*="tab"]');
  
  reviewButtons.forEach(btn => {
    const text = btn.textContent || '';
    result.allReviewText.push(text);
    
    if (text.includes('好评') || text.includes('positive')) {
      const match = text.match(/(\d+)/);
      if (match) result.reviews.good = match[1];
    }
    
    if (text.includes('中评') || text.includes('neutral')) {
      const match = text.match(/(\d+)/);
      if (match) result.reviews.neutral = match[1];
    }
    
    if (text.includes('差评') || text.includes('negative')) {
      const match = text.match(/(\d+)/);
      if (match) result.reviews.bad = match[1];
    }
  });
  
  const commentSummary = document.querySelector('[class*="comment-summary"], [class*="summary"]');
  if (commentSummary) {
    const summaryText = commentSummary.textContent || '';
    result.allReviewText.push(summaryText);
  }
  
  return result;
})()
