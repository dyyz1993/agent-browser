(() => {
  const applauseRateEl = document.querySelector('.applause-rate');
  
  if (applauseRateEl) {
    return {
      elementFound: true,
      elementText: applauseRateEl.textContent,
      elementHTML: applauseRateEl.outerHTML.substring(0, 500)
    };
  } else {
    const allElements = document.querySelectorAll('[class*="applause"], [class*="rate"]');
    const elements = [];
    allElements.forEach(el => {
      elements.push({
        className: el.className,
        text: el.textContent?.substring(0, 100)
      });
    });
    
    return {
      elementFound: false,
      message: 'applause-rate element not found',
      similarElements: elements.slice(0, 10)
    };
  }
})()
