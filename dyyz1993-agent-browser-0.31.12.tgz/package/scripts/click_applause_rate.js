(async () => {
  const applauseRateEl = document.querySelector('.applause-rate');
  
  if (applauseRateEl) {
    applauseRateEl.click();
    
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const result = {
      elementFound: true,
      elementText: applauseRateEl.textContent,
      popup: null
    };
    
    const popup = document.querySelector('[class*="popup"], [class*="modal"], [class*="dialog"]');
    if (popup) {
      result.popup = {
        className: popup.className,
        text: popup.textContent?.substring(0, 500)
      };
    }
    
    return result;
  } else {
    return {
      elementFound: false,
      message: 'applause-rate element not found'
    };
  }
})()
