#!/bin/bash
# 场景3: 文件上传验证脚本

set -e
export AGENT_BROWSER_HUMAN=bezier
SESSION="upload-verify-$(date +%s)"
TEST_PAGE="file:///Users/xuyingzhou/Project/temporary/agent-browser/test-pages/upload-test.html"
TEST_FILE="/Users/xuyingzhou/Project/temporary/agent-browser/test-pages/upload-test.txt"

echo "=== 开始执行文件上传脚本 ==="
echo "Session: $SESSION"

# 打开测试页面
echo "1. 打开文件上传测试页面..."
agent-browser --session $SESSION --allow-file-access --headed open "$TEST_PAGE"
agent-browser --session $SESSION wait --load networkidle

# 上传文件
echo "2. 上传文件..."
agent-browser --session $SESSION upload "#fileInput" "$TEST_FILE"

# 等待上传完成
agent-browser --session $SESSION wait 1000

# 验证结果
echo "3. 验证结果..."
URL=$(agent-browser --session $SESSION get url)
if [[ "$URL" == *"upload-test.html"* ]]; then
    echo "✓ URL验证成功"
else
    echo "✗ URL验证失败"
    agent-browser --session $SESSION close
    exit 1
fi

# 清理
echo "4. 关闭浏览器..."
agent-browser --session $SESSION close

echo "=== 脚本执行成功 ==="
exit 0