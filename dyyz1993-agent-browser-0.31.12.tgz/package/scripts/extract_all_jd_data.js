(() => {
  const result = {
    url: window.location.href,
    title: document.title,
    basic: {
      title: '',
      shop: '',
      price: '',
      sales: ''
    },
    reviews: {
      total: '',
      good_percent: '',
      good: '',
      neutral: '',
      bad: ''
    },
    region: ''
  };
  
  const allText = document.body.textContent;
  
  const titleMatch = allText.match(/首鲜道斑节虾[^¥]{0,200}/);
  if (titleMatch) {
    result.basic.title = titleMatch[0].trim().substring(0, 100);
  }
  
  const shopMatch = allText.match(/首鲜道旗舰店/);
  if (shopMatch) {
    result.basic.shop = shopMatch[0];
  }
  
  const priceMatch = allText.match(/[¥￥]\s*(\d+\.?\d*)/);
  if (priceMatch) {
    result.basic.price = priceMatch[1];
  }
  
  const totalReviewMatch = allText.match(/买家评价[（(](\d+[+万])[）)]/);
  if (totalReviewMatch) {
    result.reviews.total = totalReviewMatch[1];
  }
  
  const goodPercentMatch = allText.match(/超(\d+)%买家赞不绝口/);
  if (goodPercentMatch) {
    result.reviews.good_percent = goodPercentMatch[1];
  }
  
  const regionMatch = allText.match(/[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼]\s*[^\s]{0,10}(?:市|省|区|县|街道)/);
  if (regionMatch) {
    result.region = regionMatch[0].trim();
  }
  
  const filterItems = document.querySelectorAll('[class*="filter-item"], [class*="comment-item"]');
  filterItems.forEach(item => {
    const text = item.textContent || '';
    
    if (text.includes('好评') || text.includes('positive')) {
      const match = text.match(/(\d+)/);
      if (match && !result.reviews.good) {
        result.reviews.good = match[1];
      }
    }
    
    if (text.includes('中评') || text.includes('neutral')) {
      const match = text.match(/(\d+)/);
      if (match && !result.reviews.neutral) {
        result.reviews.neutral = match[1];
      }
    }
    
    if (text.includes('差评') || text.includes('negative')) {
      const match = text.match(/(\d+)/);
      if (match && !result.reviews.bad) {
        result.reviews.bad = match[1];
      }
    }
  });
  
  return result;
})()
