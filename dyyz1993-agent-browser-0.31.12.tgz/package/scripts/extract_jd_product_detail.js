(() => {
  const result = {
    url: window.location.href,
    title: document.title,
    price: '',
    shop: '',
    sales: '',
    reviews: {
      good: '',
      neutral: '',
      bad: ''
    },
    region: ''
  };
  
  const priceMatch = document.body.textContent.match(/[¥￥]\s*(\d+\.?\d*)/);
  if (priceMatch) {
    result.price = priceMatch[1];
  }
  
  const shopMatch = document.body.textContent.match(/([^\s]{2,10}(?:旗舰店|专营店|京东自营))/);
  if (shopMatch) {
    result.shop = shopMatch[1];
  }
  
  const reviewElements = document.querySelectorAll('[class*="comment"], [class*="review"], [class*="rating"]');
  
  reviewElements.forEach(el => {
    const text = el.textContent || '';
    
    if (text.includes('好评') && !result.reviews.good) {
      const match = text.match(/好评[：:]\s*(\d+)/);
      if (match) {
        result.reviews.good = match[1];
      }
    }
    
    if (text.includes('中评') && !result.reviews.neutral) {
      const match = text.match(/中评[：:]\s*(\d+)/);
      if (match) {
        result.reviews.neutral = match[1];
      }
    }
    
    if (text.includes('差评') && !result.reviews.bad) {
      const match = text.match(/差评[：:]\s*(\d+)/);
      if (match) {
        result.reviews.bad = match[1];
      }
    }
  });
  
  const regionElements = document.querySelectorAll('[class*="address"], [class*="region"], [class*="location"]');
  regionElements.forEach(el => {
    const text = el.textContent || '';
    if (!result.region && text.length > 0 && text.length < 100) {
      result.region = text.trim();
    }
  });
  
  return result;
})()
