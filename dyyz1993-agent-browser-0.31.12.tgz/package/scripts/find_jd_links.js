(() => {
  const result = {
    allLinks: [],
    jdLinks: [],
    productLinks: []
  };
  
  const links = document.querySelectorAll('a[href*="jd"]');
  
  links.forEach((link, index) => {
    if (index < 20) {
      result.allLinks.push({
        href: link.href.substring(0, 100),
        text: link.textContent?.substring(0, 50)
      });
    }
    
    if (link.href.includes('item.jd') || link.href.includes('product')) {
      result.jdLinks.push({
        href: link.href.substring(0, 100),
        text: link.textContent?.substring(0, 50),
        parentClass: link.parentElement?.className
      });
    }
  });
  
  return result;
})()
