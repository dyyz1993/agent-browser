(async () => {
  const result = {
    products: []
  };
  
  const containers = document.querySelectorAll('._goodsContainer_1p2ae_1');
  
  containers.forEach((container, index) => {
    if (index >= 10) return;
    
    const product = {
      index,
      className: container.className,
      text: container.textContent?.trim().substring(0, 300)
    };
    
    const link = container.querySelector('a[href*="jd"]');
    if (link) {
      product.link = link.href;
    }
    
    const img = container.querySelector('img');
    if (img) {
      product.img = img.getAttribute('data-src')?.substring(0, 100) || img.src?.substring(0, 100);
    }
    
    const text = container.textContent || '';
    
    const priceMatch = text.match(/[¥￥]\s*\d+\.?\d*/);
    if (priceMatch) {
      product.price = priceMatch[0];
    }
    
    const salesMatch = text.match(/已售[\d\+万]+/);
    if (salesMatch) {
      product.sales = salesMatch[0];
    }
    
    const shopMatch = text.match(/([^\s]+旗舰店|[^\s]+专营店)/);
    if (shopMatch) {
      product.shop = shopMatch[0];
    }
    
    const titleMatch = text.match(/([^\s]{5,50})/);
    if (titleMatch && !titleMatch[0].includes('广告') && !titleMatch[0].includes('旗舰店')) {
      product.title = titleMatch[0];
    }
    
    if (product.price || product.shop || product.sales) {
      result.products.push(product);
    }
  });
  
  return result;
})()
