(() => {
  const result = {
    goodsContainerCount: 0,
    sampleContainer: null,
    allClasses: []
  };
  
  const containers = document.querySelectorAll('._goodsContainer_1p2ae_1');
  result.goodsContainerCount = containers.length;
  
  if (containers.length > 0) {
    result.sampleContainer = {
      className: containers[0].className,
      innerHTML: containers[0].innerHTML.substring(0, 500),
      text: containers[0].textContent?.substring(0, 200)
    };
  }
  
  const allDivs = document.querySelectorAll('div');
  const classSet = new Set();
  allDivs.forEach(div => {
    if (div.className) {
      const classes = String(div.className).split(' ');
      classes.forEach(c => {
        if (c.includes('goods') || c.includes('item') || c.includes('product')) {
          classSet.add(c);
        }
      });
    }
  });
  
  result.allClasses = Array.from(classSet).slice(0, 20);
  
  return result;
})()
