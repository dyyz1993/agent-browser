(() => {
  const reviews = {};
  
  const goodEl = document.querySelector('.filter-items a[data-tab="good"]');
  const neutralEl = document.querySelector('.filter-items a[data-tab="neutral"]');
  const badEl = document.querySelector('.filter-items a[data-tab="bad"]');
  
  reviews.good = goodEl?.textContent?.trim() || '';
  reviews.neutral = neutralEl?.textContent?.trim() || '';
  reviews.bad = badEl?.textContent?.trim() || '';
  
  const regionEl = document.querySelector('.address-item');
  const region = regionEl?.textContent?.trim() || '';
  
  return { reviews, region };
})()
