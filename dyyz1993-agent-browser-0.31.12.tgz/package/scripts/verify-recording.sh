#!/bin/bash
# 从 complex-scene-5.yaml 生成的验证脚本
# 用于验证录制转脚本的可靠性

set -e  # 遇到错误立即退出

export AGENT_BROWSER_HUMAN=bezier
SESSION="verify-$(date +%s)"

# 测试页面路径
TEST_PAGE="file:///Users/xuyingzhou/Project/temporary/agent-browser/test-pages/complex-scene-5.html"

echo "=== 开始执行脚本 ==="
echo "Session: $SESSION"

# 打开测试页面
echo "1. 打开测试页面..."
agent-browser --session $SESSION --allow-file-access --headed open "$TEST_PAGE"
agent-browser --session $SESSION wait --load networkidle

# 执行表单填写
echo "2. 填写表单..."
agent-browser --session $SESSION fill "#username" "测试用户001"
agent-browser --session $SESSION fill "#email" "test@example.com"
agent-browser --session $SESSION fill "#comments" "这是一个自动化测试备注信息"

# 点击按钮
echo "3. 点击按钮..."
agent-browser --session $SESSION click "#btn-primary"
agent-browser --session $SESSION click "#btn-secondary"
agent-browser --session $SESSION click "#btn-success"
agent-browser --session $SESSION click "#btn-danger"

# 下拉选择
echo "4. 选择下拉选项..."
agent-browser --session $SESSION select "#country" "cn"
agent-browser --session $SESSION select "#city" "北京"

# 复选框
echo "5. 勾选复选框..."
agent-browser --session $SESSION check "#chk1"
agent-browser --session $SESSION check "#chk2"
agent-browser --session $SESSION check "#chk4"

# 单选框
echo "6. 选择单选项..."
agent-browser --session $SESSION click "#rd1"

# 计数器
echo "7. 点击计数器..."
agent-browser --session $SESSION click "#counter-increase"

# 开关
echo "8. 切换开关..."
agent-browser --session $SESSION click "#dark-mode-toggle"

# 收集数据
echo "9. 点击收集数据..."
agent-browser --session $SESSION click "#collect-data"

# 验证结果
echo "10. 验证结果..."
URL=$(agent-browser --session $SESSION get url)
echo "当前URL: $URL"

# 检查URL是否正确
if [[ "$URL" == *"complex-scene-5.html"* ]]; then
    echo "✓ URL验证成功"
else
    echo "✗ URL验证失败"
    agent-browser --session $SESSION close
    exit 1
fi

# 清理
echo "11. 关闭浏览器..."
agent-browser --session $SESSION close

echo "=== 脚本执行成功 ==="
exit 0