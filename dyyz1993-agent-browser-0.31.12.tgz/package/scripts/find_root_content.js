(() => {
  const root = document.getElementById('root');
  
  if (!root) {
    return { error: 'root not found' };
  }
  
  const result = {
    rootId: root.id,
    childrenCount: root.children.length,
    children: []
  };
  
  for (let i = 0; i < Math.min(root.children.length, 20); i++) {
    const child = root.children[i];
    result.children.push({
      index: i,
      tagName: child.tagName,
      id: child.id,
      className: child.className,
      innerHTML: child.innerHTML.substring(0, 300)
    });
  }
  
  return result;
})()
