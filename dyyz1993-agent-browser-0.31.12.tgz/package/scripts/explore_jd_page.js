(() => {
  const result = {
    productContainers: [],
    sampleProduct: null
  };
  
  const containers = document.querySelectorAll('[class*="product"], [class*="item"], [class*="card"]');
  
  containers.forEach((el, index) => {
    if (index < 5) {
      result.productContainers.push({
        className: el.className,
        tagName: el.tagName,
        innerHTML: el.innerHTML.substring(0, 200)
      });
    }
  });
  
  const links = document.querySelectorAll('a[href*="item.jd"]');
  if (links.length > 0) {
    const parent = links[0].closest('[class*="product"], [class*="item"], [class*="card"]');
    if (parent) {
      result.sampleProduct = {
        className: parent.className,
        innerHTML: parent.innerHTML.substring(0, 500)
      };
    }
  }
  
  return result;
})()
