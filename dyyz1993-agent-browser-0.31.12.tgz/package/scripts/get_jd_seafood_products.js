(async () => {
  const result = {
    products: []
  };
  
  window.scrollTo(0, 1000);
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  window.scrollTo(0, 3000);
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  const productCards = document.querySelectorAll('[data-point-id], .youLikeItem, [class*="item"]');
  
  productCards.forEach((card, index) => {
    if (index >= 15) return;
    
    const product = {
      index,
      className: card.className,
      title: '',
      price: '',
      shop: '',
      link: ''
    };
    
    const titleEl = card.querySelector('[class*="title"], [class*="name"], h3, h4, h5');
    const priceEl = card.querySelector('[class*="price"], .price');
    const shopEl = card.querySelector('[class*="shop"], [class*="store"], [class*="brand"]');
    const linkEl = card.querySelector('a[href*="jd"]');
    const imgEl = card.querySelector('img');
    
    if (titleEl) product.title = titleEl.textContent?.trim() || '';
    if (priceEl) product.price = priceEl.textContent?.trim() || '';
    if (shopEl) product.shop = shopEl.textContent?.trim() || '';
    if (linkEl) product.link = linkEl.href || '';
    if (imgEl && imgEl.src) product.image = imgEl.src.substring(0, 100);
    
    if (product.title || product.price || product.link) {
      result.products.push(product);
    }
  });
  
  return result;
})()
