#!/bin/bash
set -e

# Douyin Real-World Test Script
# Prerequisites:
#   1. Chrome running with --remote-debugging-port=9221
#      macOS: /Applications/Chromium.app/Contents/MacOS/Chromium --remote-debugging-port=9221 --user-data-dir=/tmp/chrome-debug
#   2. AGENT_BROWSER_SESSION set
#   3. agent-browser built (pnpm build)

export AGENT_BROWSER_EXECUTABLE_PATH=/Applications/Chromium.app/Contents/MacOS/Chromium
export AGENT_BROWSER_SESSION=douyin-test

WORKSPACE_DIR="./test-workspace-$(date +%s)"
mkdir -p "$WORKSPACE_DIR"

echo "========================================"
echo "  Douyin Real-World Test"
echo "========================================"
echo ""

# Step 1: Check if Chrome is running on port 9221
echo "[1/8] Checking Chrome on port 9221..."
if curl -s http://localhost:9221/json/version > /dev/null 2>&1; then
  echo "  Chrome found on port 9221"
else
  echo "  Chrome not found. Launching..."
  /Applications/Chromium.app/Contents/MacOS/Chromium --remote-debugging-port=9221 --user-data-dir=/tmp/chrome-debug &
  sleep 3
  if curl -s http://localhost:9221/json/version > /dev/null 2>&1; then
    echo "  Chrome launched successfully"
  else
    echo "  ERROR: Failed to launch Chrome"
    exit 1
  fi
fi

# Step 2: Kill any existing daemon
echo ""
echo "[2/8] Cleaning up existing daemon..."
node dist/cli.js kill --all 2>/dev/null || true
sleep 1

# Step 3: Connect to Chrome
echo ""
echo "[3/8] Connecting to Chrome..."
node dist/cli.js connect 9221
echo "  Connected"

# Step 4: Open Douyin homepage
echo ""
echo "[4/8] Opening Douyin homepage..."
node dist/cli.js open "https://www.douyin.com" --wait-until domcontentloaded
echo "  Page loaded"

# Step 5: Take snapshot to verify page loaded
echo ""
echo "[5/8] Taking snapshot..."
node dist/cli.js snapshot > "$WORKSPACE_DIR/snapshot-homepage.txt" 2>/dev/null
echo "  Snapshot saved to $WORKSPACE_DIR/snapshot-homepage.txt"
echo "  Page title:"
node dist/cli.js evaluate "document.title" 2>/dev/null || echo "  (could not get title)"

# Step 6: Start recorder
echo ""
echo "[6/8] Starting recorder..."
node dist/cli.js recorder start
echo "  Recorder started - you can interact with the page in Chrome"
echo "  Recording for 15 seconds..."

# Wait for user interaction or auto-timeout
sleep 15

# Step 7: Stop recorder and get YAML
echo ""
echo "[7/8] Stopping recorder..."
node dist/cli.js recorder stop > "$WORKSPACE_DIR/recorded-flow.yaml" 2>/dev/null
echo "  Recording saved to $WORKSPACE_DIR/recorded-flow.yaml"

# Step 8: Show recorder status
echo ""
echo "[8/8] Final status..."
node dist/cli.js recorder status 2>/dev/null || true
node dist/cli.js history 2>/dev/null | head -20 > "$WORKSPACE_DIR/history.txt" || true

echo ""
echo "========================================"
echo "  Test Complete!"
echo "========================================"
echo ""
echo "  Workspace: $WORKSPACE_DIR/"
ls -la "$WORKSPACE_DIR/"
echo ""
echo "  Next steps:"
echo "    - Review the recorded flow: cat $WORKSPACE_DIR/recorded-flow.yaml"
echo "    - Replay the flow: node dist/cli.js flow run $WORKSPACE_DIR/recorded-flow.yaml"
echo "    - Export as Playwright: node dist/cli.js flow export $WORKSPACE_DIR/recorded-flow.yaml --format playwright"
echo ""
echo "  Cleanup:"
echo "    node dist/cli.js kill --all"
echo "    rm -rf $WORKSPACE_DIR"
