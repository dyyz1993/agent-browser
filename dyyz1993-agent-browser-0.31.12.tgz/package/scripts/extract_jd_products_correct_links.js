(async () => {
  const result = {
    keyword: "生鲜海鲜",
    crawlTime: new Date().toISOString(),
    products: []
  };
  
  window.scrollTo(0, 500);
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  window.scrollTo(0, 2000);
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  window.scrollTo(0, 4000);
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  const containers = document.querySelectorAll('._goodsContainer_1p2ae_1');
  const seenLinks = new Set();
  
  containers.forEach((container, index) => {
    const link = container.querySelector('a[href]');
    if (!link) return;
    
    const href = link.href;
    if (seenLinks.has(href)) return;
    seenLinks.add(href);
    
    const text = container.textContent || '';
    const product = {
      id: index + 1,
      link: href
    };
    
    const img = container.querySelector('img');
    if (img) {
      const src = img.getAttribute('data-src') || img.src;
      if (src) product.image = src.substring(0, 150);
    }
    
    const priceMatch = text.match(/[¥￥]\s*(\d+\.?\d*)/);
    if (priceMatch) {
      product.price = priceMatch[1];
    }
    
    const salesMatch = text.match(/已售([\d\+万]+)/);
    if (salesMatch) {
      product.sales = salesMatch[1];
    }
    
    const shopMatch = text.match(/([^\s]{2,10}(?:旗舰店|专营店|京东自营))/);
    if (shopMatch) {
      product.shop = shopMatch[1];
    }
    
    const adIndex = text.indexOf('广告');
    const titleStart = adIndex >= 0 ? adIndex + 2 : 0;
    let title = text.substring(titleStart).trim();
    
    title = title.replace(/已售[\d\+万]+/, '');
    title = title.replace(/[\d\+万]+人加购/, '');
    title = title.replace(/[\d\+万]+人种草/, '');
    title = title.replace(/[\d\+万]+人浏览/, '');
    title = title.replace(/[^\s]{2,10}(?:旗舰店|专营店|京东自营)/, '');
    title = title.replace(/搜同款|关注|对比/g, '');
    title = title.trim();
    
    if (title.length > 5) {
      product.title = title.substring(0, 100);
    }
    
    if (product.title || product.price) {
      result.products.push(product);
    }
  });
  
  result.total = result.products.length;
  return result;
})()
